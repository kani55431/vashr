from employee.models import Employee, Department, Deduction, Designation, Category
from django import forms
from .models import Holiday
from django_select2.forms import Select2Widget
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Fieldset, ButtonHolder, Submit
from django import forms
from .models import AuditAttendance
from attendance.models import Attendance
import logging
import logging
from datetime import datetime, time, timedelta
import random
from collections import defaultdict
from django import forms

# Set up logging
logging.basicConfig(level=logging.DEBUG)
import logging
import random
from datetime import datetime, timedelta, time
from collections import defaultdict
from django import forms

# Set up logging
logging.basicConfig(level=logging.DEBUG)
import logging
import random
from datetime import datetime, timedelta, time
from collections import defaultdict
from django import forms

# Set up logging
logging.basicConfig(level=logging.DEBUG)

# Days of the week choices
DAYS_OF_WEEK = [
    ('Monday', 'Monday'),
    ('Tuesday', 'Tuesday'),
    ('Wednesday', 'Wednesday'),
    ('Thursday', 'Thursday'),
    ('Friday', 'Friday'),
    ('Saturday', 'Saturday'),
    ('Sunday', 'Sunday'),
]
from django import forms
from datetime import datetime, time, timedelta
from collections import defaultdict
import random

import logging
import logging
import random
from collections import defaultdict
from datetime import datetime, timedelta, time
from django import forms

import logging
import random
from collections import defaultdict
from datetime import datetime, timedelta, time
from django import forms

import logging
import random
from collections import defaultdict
from datetime import datetime, timedelta, time
from django import forms


class AttendanceImportForm(forms.Form):
    start_date = forms.DateField(
        widget=forms.TextInput(attrs={'type': 'date'}),
        label="Start Date",
    )
    end_date = forms.DateField(
        widget=forms.TextInput(attrs={'type': 'date'}),
        label="End Date",
    )

    def import_attendance(self):
        start_date = self.cleaned_data['start_date']
        end_date = self.cleaned_data['end_date']

        # Debug log for date range
        logging.debug(f"Importing attendance from {start_date} to {end_date}.")

        # Filter attendances by date range and pf_esi_applicable condition
        attendances = Attendance.objects.filter(
            date__range=[start_date, end_date],
            employee__pf_esi_applicable='yes'  # Only process records where pf_esi_applicable is 'Yes'
        )

        if not attendances.exists():
            logging.warning("No attendance records found for the selected date range.")
            return False, "No attendance records found for the selected date range."

        # Helper function to randomize the in-time and out-time by a small margin
        def random_time_within_range(base_time, range_minutes=5):
            """Generate a random time within the specified range around the base time."""
            minute_offset = random.randint(-range_minutes, range_minutes)
            return base_time + timedelta(minutes=minute_offset)

        # Track the last assigned shift for each worker to ensure proper rotation
        last_assigned_shift = defaultdict(lambda: '3')  # Default shift to '3'

        # Collect all dates in the specified range
        date_range = [start_date + timedelta(days=i) for i in range((end_date - start_date).days + 1)]

        for date in date_range:
            daily_attendance = attendances.filter(date=date)

            if daily_attendance.exists():
                # Process each attendance for this date
                for attendance in daily_attendance:
                    logging.debug(f"Processing attendance for employee: {attendance.employee_code}")

                    # Determine if the attendance date matches the employee's weekly off day
                    attendance_day = date.strftime('%A')
                    weekly_off_day = attendance.employee.weekly_off

                    if attendance_day == weekly_off_day:
                        # If it's a weekly off day, assign WO (regardless of whether employee is absent or not)
                        shift = 'WO'
                        attendance.absent = 'WO'  # Marking the employee as on WO
                        logging.debug(f"Date {date} is a Weekly Off for employee {attendance.employee_code}.")
                        intime, outtime = None, None
                    elif attendance.absent == 'P':
                        # Assign shift based on the employee's category
                        employee_category = (attendance.employee.category.name or '').strip().upper() if attendance.employee and attendance.employee.category else ''

                        if employee_category in ['STAFF', 'STAFFS']:
                            # Fixed shift for STAFF and G_SHIFT employees
                            shift = 'G'
                            base_intime = datetime.combine(date, time(9, 30))
                            base_outtime = datetime.combine(date, time(18, 30))

                            # Randomize in-time and out-time within a small range
                            intime = random_time_within_range(base_intime)
                            outtime = random_time_within_range(base_outtime)

                        elif employee_category in ['SEMI STAFF']:
                            shift = 'G'
                            base_intime = datetime.combine(date, time(8, 0))
                            base_outtime = datetime.combine(date, time(17, 0))

                            # Randomize in-time and out-time within a small range
                            intime = random_time_within_range(base_intime)
                            outtime = random_time_within_range(base_outtime)
                        elif employee_category in  ['WORKER','SECURITY']:
                            # Handle rotating shifts for WORKERS
                            previous_shift = last_assigned_shift[attendance.employee_code]
                            if previous_shift == '1':
                                shift = '2'
                            elif previous_shift == '2':
                                shift = '3'
                            else:
                                shift = '1'

                            # Update the last assigned shift for the employee
                            last_assigned_shift[attendance.employee_code] = shift

                            # Assign base in-time and out-time based on the shift
                            if shift == '1':
                                base_intime = datetime.combine(date, time(7, 0))
                                base_outtime = datetime.combine(date, time(15, 0))
                            elif shift == '2':
                                base_intime = datetime.combine(date, time(15, 0))
                                base_outtime = datetime.combine(date, time(23, 0))
                            else:  # shift == '3'
                                base_intime = datetime.combine(date, time(23, 0))
                                base_outtime = datetime.combine(date, time(7, 0))

                            # Randomize in-time and out-time
                            intime = random_time_within_range(base_intime)
                            outtime = random_time_within_range(base_outtime)
                        else:
                            logging.warning(f"Unknown category for employee {attendance.employee_code}. Skipping.")
                            continue
                    else:
                        # Absent (AB) employees for non-weekly off days
                        shift = 'AB'
                        intime, outtime = None, None

                    # Calculate total working hours
                    total_working_hours = round((outtime - intime).seconds / 3600.0) if intime and outtime else 0

                    # Update or create AuditAttendance record
                    audit_attendance, created = AuditAttendance.objects.update_or_create(
                        employee_code=attendance.employee_code,
                        employee=attendance.employee,
                        category=attendance.employee.category.name,
                        department=attendance.employee.department,
                        date=date,
                        defaults={
                            'intime': intime if shift not in ['WO', 'AB'] else None,
                            'intime_direction': attendance.intime_direction if intime and shift not in ['WO', 'AB'] else None,
                            'outtime': outtime if shift not in ['WO', 'AB'] else None,
                            'outtime_direction': attendance.outtime_direction if outtime and shift not in ['WO', 'AB'] else None,
                            'shift': shift,
                            'total_working_hours': total_working_hours,
                            'ot_hours': 0,  # Default OT hours to 0
                            'p1': attendance.p1,
                            'p1_direction': attendance.p1_direction,
                            'p2': attendance.p2,
                            'p2_direction': attendance.p2_direction,
                            'p3': attendance.p3,
                            'p3_direction': attendance.p3_direction,
                            'p4': attendance.p4,
                            'p4_direction': attendance.p4_direction,
                            'p5': attendance.p5,
                            'p5_direction': attendance.p5_direction,
                            'p6': attendance.p6,
                            'p6_direction': attendance.p6_direction,
                            'p7': attendance.p7,
                            'p7_direction': attendance.p7_direction,
                            'p8': attendance.p8,
                            'p8_direction': attendance.p8_direction,
                            'p9': attendance.p9,
                            'p9_direction': attendance.p9_direction,
                            'p10': attendance.p10,
                            'p10_direction': attendance.p10_direction,
                            'adjustment': attendance.adjustment,
                            'adjustment_count': attendance.adjustment_count,
                            'absent': attendance.absent,  # Ensure absent is correctly updated
                            'user': attendance.user,
                        }
                    )

                    if created:
                        logging.info(f"Created attendance record for employee {attendance.employee_code} on {date}")
                    else:
                        logging.info(f"Updated attendance record for employee {attendance.employee_code} on {date}")

            else:
                # If no attendance exists for this date, create a Weekly Off record
                for attendance in attendances:  # Loop through employees who were originally fetched
                    employee = attendance.employee
                    weekly_off_day = employee.weekly_off
                    if date.strftime('%A') == weekly_off_day:
                        shift = 'WO'
                        logging.debug(f"Creating Weekly Off record for employee: {employee.employee_code} on {date}")
                        intime, outtime = None, None
                    else:
                        shift = 'AB'
                        intime, outtime = None, None

                    # Create new AuditAttendance record for Weekly Off or Absent
                    AuditAttendance.objects.update_or_create(
                        employee_code=employee.employee_code,
                        employee=employee,
                        category=employee.category.name,
                        department=employee.department,
                        date=date,
                        intime=intime,
                        outtime=outtime,
                        shift=shift,
                        total_working_hours=0,
                        ot_hours=0,
                        absent=shift,  # Mark as WO or AB
                        user=employee.user,  # Assuming user is part of the employee model
                    )
                    logging.info(f"Created Weekly Off record for employee {employee.employee_code} on {date}")

        return True, f'Successfully imported {attendances.count()} records from {start_date} to {end_date}.'



class EmployeeForm(forms.ModelForm):
    class Meta:
        model = Employee
        fields = '__all__'
        widgets = {
            'date_of_birth': forms.DateInput(attrs={'type': 'date', 'class': 'dob-input'}),
            'date_of_joining': forms.DateInput(attrs={'type': 'date'}),
            'date_of_re_joining': forms.DateInput(attrs={'type': 'date'}),
            'date_of_leaving': forms.DateInput(attrs={'type': 'date'}),
            'pf_date_of_joining': forms.DateInput(attrs={'type': 'date'}),
            'department': Select2Widget,
            'category': Select2Widget,
            'designation': Select2Widget,
            'user': Select2Widget,
            'qualification': Select2Widget,
            'marital_status': Select2Widget,
            'gender': Select2Widget,
            'pf_esi_applicable': Select2Widget,
            'nominee_relationship': Select2Widget,
            'migrant_worker': Select2Widget,
            'working_mode': Select2Widget,
            'weekly_off': Select2Widget,
            'status': Select2Widget,
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.layout = Layout(
            Fieldset(
                'Employee Details',
                'employee_code',
                'employee_name',
                'employee_mobile',
                'emergency_mobile',
                'father_or_husband_name',
                'address_1',
                'street',
                'city',
                'district',
                'state',
                'pincode',
                'date_of_birth',
                'age',
                'qualification',
                'marital_status',
                'blood_group',
                'gender',
                'department',
                'category',
                'designation',
                'weekly_off',
                'date_of_joining',
                'date_of_re_joining',
                'date_of_leaving',
                'pf_esi_applicable',
                'pf_date_of_joining',
                'pf_no',
                'esi_no',
                'bank_name',
                'account_holder',
                'account_no',
                'ifsc_code',
                'branch',
                'nominee_name',
                'nominee_relationship',
                'nominee_age',
                'employee_photo',
                'aadhar_number',
                'migrant_worker',
                'working_mode',
                'status'
            ),
            ButtonHolder(
                Submit('submit', 'Save', css_class='btn btn-primary')
            )
        )

    class Media:
        js = ('assets/js/calculate_age.js',)  # Define the path to your JavaScript file


class HolidayForm(forms.ModelForm):
    class Meta:
        model = Holiday
        fields = ['date', 'holiday_type', 'festival_name']

        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'holiday_type': forms.Select(),
            'festival_name': forms.TextInput(attrs={'placeholder': 'Optional if not Festival'}),
        }
# forms.py



class PunchingReportForm(forms.Form):
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
# forms.py

class SinglePunchReportForm(forms.Form):
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))

# forms.py

class AbsentListForm(forms.Form):
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))


class AuditAdjustmentDateForm(forms.Form):
    date = forms.DateField(label='Select Date', widget=forms.DateInput(attrs={'type': 'date'}))

class AuditAdjustmentEntryForm(forms.Form):
    employee_code = forms.CharField(label='Employee Code', max_length=100)
    absent = forms.ChoiceField(label='P/AB', choices=[('AB', 'AB'), ('P', 'P')])

class AuditAdjustmentReportViewForm(forms.Form):
    date = forms.DateField(label='Select Date', widget=forms.DateInput(attrs={'type': 'date'}))



class MonthlyAttendanceForm(forms.Form):
    start_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    end_date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    category = forms.ModelChoiceField(queryset=Category.objects.all(), required=False)
    department = forms.ModelChoiceField(queryset=Department.objects.all(), required=False)


class TimeCardForm(forms.Form):
    employee_code = forms.ModelChoiceField(
        queryset=Employee.objects.all(),
        to_field_name='employee_code',
        required=False,
        label='Employee Code'
    )
    category = forms.ModelChoiceField(queryset=Category.objects.all(), required=False)
    department = forms.ModelChoiceField(
        queryset=Department.objects.all(),
        required=False,
        label='Department'
    )
    month = forms.DateField(
        widget=forms.SelectDateWidget(),
        required=True,
        label='Month'
    )

    month = forms.DateField(widget=forms.SelectDateWidget(years=range(2024, 2030)), label='Month', required=True)



class PfSalaryForm(forms.Form):
    month = forms.DateField(
        widget=forms.SelectDateWidget(years=range(2024, 2100)),  # Adjust year range as needed
        label='Month',
        required=True
    )
    category = forms.ModelChoiceField(
        queryset=Category.objects.all(),
        required=False,
        label='Category'
    )
    department = forms.ModelChoiceField(
        queryset=Department.objects.all(),
        required=False,
        label='Department'
    )



class EmployeeSalaryForm(forms.Form):
    employee_code = forms.ModelChoiceField(
        queryset=Employee.objects.all(),
        to_field_name='employee_code',  # Use employee_code for the selection
        required=False,  # Not required to allow "All Employees" selection
        label='Employee Code',
        empty_label='All Employees'  # Allows an option for all employees
    )
    category = forms.ModelChoiceField(
        queryset=Category.objects.all(),
        required=False,
        label='Category'
    )
    month = forms.DateField(widget=forms.SelectDateWidget(years=range(2024, 2050)), required=True, label='Month')




